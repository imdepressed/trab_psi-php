<?php session_start(); ?>
<?php
if (! Isset($_SESSION[user]))
  {
    header ("Location:error.php");
  }
elseif (! Isset($_COOKIE[cookie1])) 
  {
    header ("Location:error.php");
  }
else
  {
  	header("Location:main.html");
  }
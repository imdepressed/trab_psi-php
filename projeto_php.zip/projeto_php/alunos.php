<?php session_start(); ?>
<?php header("Content-Type: text/html; charset=utf-8",true); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css.css">
<title>Galeria de Imagens</title>
</head>
<body background="images/bck_main.jpg" style="font-family: verdana; color: white">
	<nav id="menu" style="font-family: Trebuchet MS, Helvetica, sans-serif">
    <ul>
        <li><a href="main.html">Home</a></li>
        <li><a href="about.html">About Us</a></li>
        <li><a href="galeria.html">Galeria</a></li>
        <li><a href="projeto_ow_psi.html">Overwatch Info</a></li>
        <li><a href="alunos.php">Alunos</a></li>
        <li><a href="login.html">Login</a></li>
        <li style="float: right"><a align="center" href="login.html" onclick="session_destroy()" ;="" $login="0;&quot;">Terminar sessão</a></li>
    </ul>
	</nav>
	<h1>Alunos</h1>
	<p>► Aqui estão os alunos do 2º turno da turma 12ºC:</p>
	<?php
        $a1 = array ( "Jorge"=>18, "José"=>18, "Pedro"=>17, "Rafa"=>17, "Ricardo R"=>17, "Ricardo S"=>17, "Sergio"=>17, "Sergiu"=>18);
        foreach ($a1 as $nome => $idade)
        {
            echo "Nome do Aluno: " .$nome . " - Idade: ".$idade . "<br>"; 
        }
        ?>
    <p align="center"><img src="images/aemtg_2.jpg" style="max-width: 60%"></p>
</body>
</html>
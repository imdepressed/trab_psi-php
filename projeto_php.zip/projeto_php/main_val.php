<?php session_start(); ?>
<?php
if (! Isset($_SESSION[user]))
{
    header ("Location:error.php");
}
elseif (! Isset($_COOKIE[cookie1])) 
{
    header ("Location:error.php");
}
else
{
	echo'
	<html>
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css.css">
	<title>Página Inicial</title>
</head>
<body background="images/bck_main.jpg" style="font-family: verdana; color: white">
	<nav id="menu" style="font-family: Trebuchet MS, Helvetica, sans-serif">
    <ul>
        <li><a class="active" href="main.html">Home</a></li>
        <li><a href="about.html">About Us</a></li>
        <li><a href="#">Página 3</a></li>
        <li><a href="#">Página 4</a></li>
        <li><a href="#">Página 5</a></li>
        <li style="float: right"><a href="login.html">Terminar sessão</a></li>
    </ul>
	</nav>
	<h1 style="color: white">Bem-vindo à página inicial!</h1><br>
    <br>
    → Nesta página está apresentada na barra no topo as respectivas páginas do site
    <br><br>
    <img src="images/aemtg.png" style="max-width: 40%">
</body>
</html>'

}
?>
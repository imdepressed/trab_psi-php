<?php session_start(); ?>
<?php header("Content-Type: text/html; charset=utf-8",true); ?>
<?php
echo'<html>
	<body style="font-family: verdana; position: absolute;top: 50%;left: 50%;transform: translateX(-50%) translateY(-50%);">
		<h1 style="margin-left: 45px;">Ups algo não está bem...</h1>
		<h2>Clica no "Voltar" para voltares ao Login</h2><a align="center" href="login.html" onclick="session_destroy()" ;="" $login="0;&quot;" style="color:red;margin: 220px;">&lt;-- Voltar</a><br>
		<p align="center" style="color: red;font-size: 200px;margin-top: -370px;">⚠</p>
	</body>
	</html>';
?>
<?php session_start(); ?>
<?php header("Content-Type: text/html; charset=utf-8",true); ?>
<?php
if (! Isset($_SESSION[user]))
  {
    header ("Location:error.php");
  }
elseif (! Isset($_COOKIE[cookie1])) 
  {
    header ("Location:error.php");
  }
else
  {
  	echo '
  	<html>
	<body background="images/bck_post.jpg">
		<h1 style="color: white" align="center"> Seja bem-vindo, ' .$_SESSION[user].'!</h1>
		<div id="image" align="center">
      		<img id="dva" src="images/smile.png" style="position: relative; margin-top: 50px; left: 0px; top: -17px;">
    	</div><br>
    	<div id="exit" align="center">
    <a align="center" href="post_main_val.php" style="color: #00e600; font-family: verdana"><b>Seguir--><b></a><br>
    <br>
		<a align="center" href="login.html" onclick="session_destroy()"; $login=0;" style="color: red; font-family: verdana"><--Terminar sessão</a>
  		</div>
	</body>
	</html>';
  }
?>
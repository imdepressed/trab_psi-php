<?php session_start(); ?>

<?php

$user = $_POST[username];
$pass = $_POST[password];

if ($user == "user" && $pass == "user")
	{
		$_SESSION[user] = $user;
		setcookie(cookie1,$user,time()+60);
		header("location:post_main.php");
	}
elseif ($user == "admin" && $pass == "admin") 
	{
		$_SESSION[user] = $user;
		setcookie(cookie1,$user,time()+5);
		header("location:main.html");
	}
else{
		header("location:error.php");
	}
?>